<?php
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_name = trim($_POST['room_name'] ?? '');
    $type = trim($_POST['type'] ?? '');
    $capacity = (int)($_POST['capacity'] ?? 1);
    $price = (float)($_POST['price'] ?? 0);
    $status = trim($_POST['status'] ?? 'available');
    $description = trim($_POST['description'] ?? '');
    $image = trim($_POST['image'] ?? '');
    $stmt = $conn->prepare('INSERT INTO rooms (room_name, type, capacity, price, status, description, image) VALUES (?, ?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('ssidsss', $room_name, $type, $capacity, $price, $status, $description, $image);
    $stmt->execute();
    header('Location: rooms.php');
    exit;
}

$result = $conn->query('SELECT * FROM rooms ORDER BY id DESC');
$rooms = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <title>Room Management | Kaizer B&B</title> <link rel="stylesheet" href="../assets/style.css" /> </head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h3>Kaizer B&B</h3>
    <a href="dashboard.php">Dashboard</a>
    <a class="active" href="rooms.php">Room Management</a>
    <a href="customers.php">Customer Management</a>
    <a href="bookings.php">Bookings</a>
    <a href="payments.php">Payments</a>
    <a href="reports.php">Reports</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </aside>
  <main class="main-panel">
    <div class="topbar-admin"><div><p class="eyebrow">ROOMS</p><h2>Room Management</h2></div></div>
    <div class="panel" style="margin-bottom:20px;">
      <h3>Add Room</h3>
      <form method="POST" class="form-grid">
        <div><label>Room Name</label><input name="room_name" required /></div>
        <div><label>Type</label><input name="type" required /></div>
        <div><label>Capacity</label><input type="number" name="capacity" value="2" required /></div>
        <div><label>Price</label><input type="number" step="0.01" name="price" value="1800" required /></div>
        <div><label>Status</label><select name="status"><option value="available">Available</option><option value="booked">Booked</option><option value="maintenance">Maintenance</option></select></div>
        <div><label>Image URL</label><input name="image" /></div>
        <div style="grid-column:1 / -1;"><label>Description</label><textarea name="description" rows="3"></textarea></div>
        <div style="grid-column:1 / -1;"><button class="btn btn-primary" type="submit">Save Room</button></div>
      </form>
    </div>
    <div class="panel">
      <h3>Existing Rooms</h3>
      <table class="table">
        <thead><tr><th>Name</th><th>Type</th><th>Capacity</th><th>Price</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($rooms as $room): ?>
            <tr>
              <td><?= htmlspecialchars($room['room_name']) ?></td>
              <td><?= htmlspecialchars($room['type']) ?></td>
              <td><?= (int)$room['capacity'] ?></td>
              <td>R <?= number_format((float)$room['price'], 2) ?></td>
              <td><span class="status-badge"><?= htmlspecialchars($room['status']) ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</div>
</body>
</html>
