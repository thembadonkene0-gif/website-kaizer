<?php
function send_booking_confirmation($conn, $booking_id, $payment_method, $amount, $reference = '') {
    $stmt = $conn->prepare(
        'SELECT b.id, b.check_in, b.check_out, b.total_amount, b.payment_status, b.status, c.full_name, c.email, r.room_name ' .
        'FROM bookings b JOIN customers c ON c.id = b.customer_id JOIN rooms r ON r.id = b.room_id WHERE b.id = ?'
    );
    $stmt->bind_param('i', $booking_id);
    $stmt->execute();
    $booking = $stmt->get_result()->fetch_assoc();

    if (!$booking || empty($booking['email'])) {
        return false;
    }

    $subject = 'Kaizer B&B payment confirmation';
    $body = "Hello {$booking['full_name']},\n\n";
    $body .= "Your payment for booking #{$booking['id']} has been received.\n";
    $body .= "Room: {$booking['room_name']}\n";
    $body .= "Dates: {$booking['check_in']} to {$booking['check_out']}\n";
    $body .= "Amount paid: R " . number_format((float)$amount, 2) . "\n";
    $body .= "Payment method: " . ucfirst($payment_method) . "\n";
    if ($reference !== '') {
        $body .= "Reference: {$reference}\n";
    }
    $body .= "\nThank you for staying with Kaizer B&B.\n";

    $headers = "From: no-reply@kaizerbnb.com\r\n";
    $headers .= "Reply-To: reservations@kaizerbnb.com\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $sent = mail($booking['email'], $subject, $body, $headers);

    if (!$sent) {
        $log_dir = __DIR__ . '/../storage';
        if (!is_dir($log_dir)) {
            mkdir($log_dir, 0777, true);
        }
        $log_file = $log_dir . '/email_log.txt';
        $entry = date('c') . "\nTo: {$booking['email']}\nSubject: {$subject}\n" . $body . "\n---\n";
        file_put_contents($log_file, $entry, FILE_APPEND);
    }

    return $sent;
}
?>
