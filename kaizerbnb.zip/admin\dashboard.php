<?php
session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
require '../db.php';

$stats = [
    'rooms' => $conn->query("SELECT COUNT(*) AS c FROM rooms")->fetch_assoc()['c'],
    'customers' => $conn->query("SELECT COUNT(*) AS c FROM customers")->fetch_assoc()['c'],
    'bookings' => $conn->query("SELECT COUNT(*) AS c FROM bookings")->fetch_assoc()['c'],
    'revenue' => $conn->query("SELECT COALESCE(SUM(amount),0) AS c FROM payments")->fetch_assoc()['c'],
    'pending' => $conn->query("SELECT COUNT(*) AS c FROM bookings WHERE status='pending'")->fetch_assoc()['c'],
    'confirmed' => $conn->query("SELECT COUNT(*) AS c FROM bookings WHERE status='confirmed'")->fetch_assoc()['c'],
];

$recent = $conn->query("SELECT b.id, c.full_name, r.room_name, b.check_in, b.check_out, b.status, b.payment_status FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN rooms r ON r.id=b.room_id ORDER BY b.created_at DESC LIMIT 8");
$occupancy = $conn->query("SELECT room_name, COUNT(*) AS bookings FROM bookings b JOIN rooms r ON r.id=b.room_id GROUP BY room_id ORDER BY bookings DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard | Kaizer B&B</title>
  <link rel="stylesheet" href="../assets/style.css" />
</head>
<body>
  <div class="layout">
    <aside class="sidebar">
      <h3>Kaizer B&B</h3>
      <a class="active" href="dashboard.php">Dashboard</a>
      <a href="rooms.php">Room Management</a>
      <a href="customers.php">Customer Management</a>
      <a href="bookings.php">Bookings</a>
      <a href="payments.php">Payments</a>
      <a href="reports.php">Reports</a>
      <a href="settings.php">Settings</a>
      <a href="logout.php">Logout</a>
    </aside>
    <main class="main-panel">
      <div class="topbar-admin">
        <div>
          <p class="eyebrow">ADMIN PANEL</p>
          <h2>Dashboard</h2>
        </div>
        <div>Welcome, <?= htmlspecialchars($_SESSION['admin_name']) ?></div>
      </div>

      <div class="dashboard-grid">
        <div class="stat-box"><h4>Rooms</h4><p><?= (int)$stats['rooms'] ?></p></div>
        <div class="stat-box"><h4>Customers</h4><p><?= (int)$stats['customers'] ?></p></div>
        <div class="stat-box"><h4>Bookings</h4><p><?= (int)$stats['bookings'] ?></p></div>
        <div class="stat-box"><h4>Revenue</h4><p>R <?= number_format((float)$stats['revenue'], 2) ?></p></div>
        <div class="stat-box"><h4>Pending</h4><p><?= (int)$stats['pending'] ?></p></div>
        <div class="stat-box"><h4>Confirmed</h4><p><?= (int)$stats['confirmed'] ?></p></div>
      </div>

      <div class="dashboard-grid-two">
        <div class="panel">
          <h3>Recent Bookings</h3>
          <table class="table">
            <thead>
              <tr><th>Booking</th><th>Customer</th><th>Room</th><th>Dates</th><th>Status</th><th>Payment</th></tr>
            </thead>
            <tbody>
              <?php while ($row = $recent->fetch_assoc()): ?>
                <tr>
                  <td>#<?= (int)$row['id'] ?></td>
                  <td><?= htmlspecialchars($row['full_name']) ?></td>
                  <td><?= htmlspecialchars($row['room_name']) ?></td>
                  <td><?= htmlspecialchars($row['check_in']) ?> → <?= htmlspecialchars($row['check_out']) ?></td>
                  <td><span class="status-badge"><?= htmlspecialchars($row['status']) ?></span></td>
                  <td><?= htmlspecialchars($row['payment_status']) ?></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
        <div class="panel">
          <h3>Popular Rooms</h3>
          <ul class="stack-list">
            <?php while ($row = $occupancy->fetch_assoc()): ?>
              <li><span><?= htmlspecialchars($row['room_name']) ?></span><strong><?= (int)$row['bookings'] ?> bookings</strong></li>
            <?php endwhile; ?>
          </ul>
        </div>
      </div>
    </main>
  </div>
</body>
</html>
