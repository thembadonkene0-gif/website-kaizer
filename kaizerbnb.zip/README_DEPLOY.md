# Kaizer B&B Deployment Instructions for InfinityFree

## 1. Export your local files
A ZIP package of the current project is available as `kaizerbnb.zip` in the project root.

## 2. Create an InfinityFree account
1. Go to https://www.infinityfree.com
2. Sign up or log in.
3. Create a new Free Hosting account.
4. Choose a subdomain or connect your own domain.

## 3. Upload the site files
1. In the InfinityFree Control Panel, open the File Manager.
2. Navigate to the `htdocs` folder.
3. Upload `kaizerbnb.zip`.
4. Use the File Manager to extract the zip into `htdocs`.

## 4. Configure PHP and database support
InfinityFree supports PHP but does not allow MySQL on the free plan. To use this project, you have two options:

### Option A: Use a remote MySQL host
1. Sign up for a remote MySQL host (such as free providers or a paid host).
2. In `db.php`, update the credentials to match the remote database host.
3. Make sure the remote host allows connections from InfinityFree.

### Option B: Use InfinityFree’s MySQL database on a paid plan
1. Upgrade to a plan with MySQL support or purchase a database addon.
2. Create a MySQL database in the InfinityFree control panel.
3. Update `db.php` with the new host, database name, username, and password.

## 5. Initialize the database
1. In the browser, navigate to `http://your-subdomain.infinityfreeapp.com/install.php`.
2. If the installer runs, it will create the required tables and seed initial data.
3. If any errors appear, copy them and adjust `db.php` or your hosting database settings.

## 6. Test the website
1. Open your site URL.
2. Ensure the homepage loads and the admin login works.
3. Log in to `admin/login.php` with:
   - Email: `admin@kaizerbnb.com`
   - Password: `password`

## 7. Notes
- InfinityFree free hosting usually restricts outbound SMTP mail; email confirmation may not work unless you configure a remote mail provider.
- If you need PHP session persistence or file-based storage, keep the `storage` folder writable.

## 8. Recommended next step
If InfinityFree does not support your database needs, consider a low-cost PHP hosting provider with MySQL like 000webhost, Hostinger, or a VPS.
