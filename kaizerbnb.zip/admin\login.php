<?php
session_start();
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $stmt = $conn->prepare('SELECT * FROM admins WHERE email = ?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $admin = $stmt->get_result()->fetch_assoc();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_name'] = $admin['name'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login | Kaizer B&B</title>
  <link rel="stylesheet" href="../assets/style.css" />
</head>
<body>
  <div class="container" style="min-height:100vh; display:grid; place-items:center;">
    <div class="panel" style="width:min(460px,100%);">
      <h2 style="margin-top:0;">Admin Login</h2>
      <p>Secure access to Kaizer B&B management.</p>
      <?php if (!empty($error)) echo '<p style="color:#ffb3b3;">' . htmlspecialchars($error) . '</p>'; ?>
      <form method="POST">
        <label>Email</label>
        <input type="email" name="email" required />
        <label>Password</label>
        <input type="password" name="password" required />
        <button class="btn btn-primary" type="submit">Login</button>
      </form>
    </div>
  </div>
</body>
</html>
