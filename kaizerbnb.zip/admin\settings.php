<?php
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
require '../db.php';

$settings = $conn->query('SELECT * FROM settings ORDER BY id DESC LIMIT 1')->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = trim($_POST['site_name'] ?? 'Kaizer B&B');
    $currency = trim($_POST['currency'] ?? 'ZAR');
    $tax_rate = (float)($_POST['tax_rate'] ?? 0);
    $contact_email = trim($_POST['contact_email'] ?? '');
    $contact_phone = trim($_POST['contact_phone'] ?? '');
    $stmt = $conn->prepare('UPDATE settings SET site_name=?, currency=?, tax_rate=?, contact_email=?, contact_phone=? WHERE id=1');
    $stmt->bind_param('ssdss', $site_name, $currency, $tax_rate, $contact_email, $contact_phone);
    $stmt->execute();
    header('Location: settings.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <title>Admin Settings | Kaizer B&B</title> <link rel="stylesheet" href="../assets/style.css" /> </head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h3>Kaizer B&B</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="rooms.php">Room Management</a>
    <a href="customers.php">Customer Management</a>
    <a href="bookings.php">Bookings</a>
    <a href="payments.php">Payments</a>
    <a href="reports.php">Reports</a>
    <a class="active" href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </aside>
  <main class="main-panel">
    <div class="topbar-admin"><div><p class="eyebrow">SETTINGS</p><h2>Admin Settings</h2></div></div>
    <div class="panel">
      <form method="POST" class="form-grid">
        <div><label>Site Name</label><input name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? 'Kaizer B&B') ?>" /></div>
        <div><label>Currency</label><input name="currency" value="<?= htmlspecialchars($settings['currency'] ?? 'ZAR') ?>" /></div>
        <div><label>Tax Rate</label><input type="number" step="0.01" name="tax_rate" value="<?= htmlspecialchars($settings['tax_rate'] ?? '0.00') ?>" /></div>
        <div><label>Contact Email</label><input name="contact_email" value="<?= htmlspecialchars($settings['contact_email'] ?? '') ?>" /></div>
        <div><label>Contact Phone</label><input name="contact_phone" value="<?= htmlspecialchars($settings['contact_phone'] ?? '') ?>" /></div>
        <div style="grid-column:1 / -1;"><button class="btn btn-primary" type="submit">Save Settings</button></div>
      </form>
    </div>
  </main>
</div>
</body>
</html>
