<?php
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_status') {
        $booking_id = (int)($_POST['booking_id'] ?? 0);
        $status = trim($_POST['status'] ?? 'pending');
        $payment_status = trim($_POST['payment_status'] ?? 'unpaid');
        $stmt = $conn->prepare('UPDATE bookings SET status = ?, payment_status = ? WHERE id = ?');
        $stmt->bind_param('ssi', $status, $payment_status, $booking_id);
        $stmt->execute();
        header('Location: bookings.php');
        exit;
    }

    $customer_id = (int)($_POST['customer_id'] ?? 0);
    $room_id = (int)($_POST['room_id'] ?? 0);
    $check_in = trim($_POST['check_in'] ?? '');
    $check_out = trim($_POST['check_out'] ?? '');
    $guests = (int)($_POST['guests'] ?? 1);
    $total_amount = (float)($_POST['total_amount'] ?? 0);
    $status = trim($_POST['status'] ?? 'pending');
    $payment_status = trim($_POST['payment_status'] ?? 'unpaid');
    $stmt = $conn->prepare('INSERT INTO bookings (customer_id, room_id, check_in, check_out, guests, total_amount, status, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('iisssdss', $customer_id, $room_id, $check_in, $check_out, $guests, $total_amount, $status, $payment_status);
    $stmt->execute();
    header('Location: bookings.php');
    exit;
}

$customers = $conn->query('SELECT id, full_name FROM customers ORDER BY full_name ASC')->fetch_all(MYSQLI_ASSOC);
$rooms = $conn->query('SELECT id, room_name, price FROM rooms ORDER BY room_name ASC')->fetch_all(MYSQLI_ASSOC);
$bookings = $conn->query('SELECT b.*, c.full_name, r.room_name FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN rooms r ON r.id=b.room_id ORDER BY b.id DESC')->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <title>Booking Management | Kaizer B&B</title> <link rel="stylesheet" href="../assets/style.css" /> </head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h3>Kaizer B&B</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="rooms.php">Room Management</a>
    <a href="customers.php">Customer Management</a>
    <a class="active" href="bookings.php">Bookings</a>
    <a href="payments.php">Payments</a>
    <a href="reports.php">Reports</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </aside>
  <main class="main-panel">
    <div class="topbar-admin"><div><p class="eyebrow">BOOKINGS</p><h2>Booking Management</h2></div></div>
    <div class="panel" style="margin-bottom:20px;">
      <h3>Create Booking</h3>
      <form method="POST" class="form-grid">
        <div><label>Customer</label><select name="customer_id">
          <?php foreach ($customers as $customer): ?><option value="<?= (int)$customer['id'] ?>"><?= htmlspecialchars($customer['full_name']) ?></option><?php endforeach; ?></select></div>
        <div><label>Room</label><select name="room_id">
          <?php foreach ($rooms as $room): ?><option value="<?= (int)$room['id'] ?>"><?= htmlspecialchars($room['room_name']) ?> - R <?= number_format((float)$room['price'],2) ?></option><?php endforeach; ?></select></div>
        <div><label>Check-in</label><input type="date" name="check_in" required /></div>
        <div><label>Check-out</label><input type="date" name="check_out" required /></div>
        <div><label>Guests</label><input type="number" name="guests" value="2" /></div>
        <div><label>Total Amount</label><input type="number" step="0.01" name="total_amount" value="1800" /></div>
        <div><label>Status</label><select name="status"><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="cancelled">Cancelled</option></select></div>
        <div><label>Payment Status</label><select name="payment_status"><option value="unpaid">Unpaid</option><option value="paid">Paid</option></select></div>
        <div style="grid-column:1 / -1;"><button class="btn btn-primary" type="submit">Save Booking</button></div>
      </form>
    </div>
    <div class="panel">
      <h3>Booking Records</h3>
      <table class="table"><thead><tr><th>Booking</th><th>Customer</th><th>Room</th><th>Dates</th><th>Status</th><th>Payment</th><th>Action</th></tr></thead><tbody>
        <?php foreach ($bookings as $booking): ?><tr><td>#<?= (int)$booking['id'] ?></td><td><?= htmlspecialchars($booking['full_name']) ?></td><td><?= htmlspecialchars($booking['room_name']) ?></td><td><?= htmlspecialchars($booking['check_in']) ?> → <?= htmlspecialchars($booking['check_out']) ?></td><td><span class="status-badge"><?= htmlspecialchars($booking['status']) ?></span></td><td><?= htmlspecialchars($booking['payment_status']) ?></td><td>
          <form method="POST" class="inline-form">
            <input type="hidden" name="action" value="update_status" />
            <input type="hidden" name="booking_id" value="<?= (int)$booking['id'] ?>" />
            <select name="status">
              <option value="pending" <?= $booking['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
              <option value="confirmed" <?= $booking['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
              <option value="cancelled" <?= $booking['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
            </select>
            <select name="payment_status">
              <option value="unpaid" <?= $booking['payment_status'] === 'unpaid' ? 'selected' : '' ?>>Unpaid</option>
              <option value="paid" <?= $booking['payment_status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
            </select>
            <button class="btn btn-small" type="submit">Save</button>
          </form>
        </td></tr><?php endforeach; ?>
      </tbody></table>
    </div>
  </main>
</div>
</body>
</html>
