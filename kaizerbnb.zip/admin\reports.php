<?php
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
require '../db.php';

$bookings = $conn->query("SELECT b.id, c.full_name, r.room_name, b.total_amount, b.status, b.payment_status FROM bookings b JOIN customers c ON c.id=b.customer_id JOIN rooms r ON r.id=b.room_id ORDER BY b.id DESC")->fetch_all(MYSQLI_ASSOC);
$revenue = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM payments")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <title>Reports | Kaizer B&B</title> <link rel="stylesheet" href="../assets/style.css" /> </head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h3>Kaizer B&B</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="rooms.php">Room Management</a>
    <a href="customers.php">Customer Management</a>
    <a href="bookings.php">Bookings</a>
    <a href="payments.php">Payments</a>
    <a class="active" href="reports.php">Reports</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </aside>
  <main class="main-panel">
    <div class="topbar-admin"><div><p class="eyebrow">REPORTS</p><h2>Reports</h2></div></div>
    <div class="dashboard-grid">
      <div class="stat-box"><h4>Total Revenue</h4><p>R <?= number_format((float)$revenue, 2) ?></p></div>
      <div class="stat-box"><h4>Bookings</h4><p><?= count($bookings) ?></p></div>
    </div>
    <div class="panel">
      <h3>Booking Summary</h3>
      <table class="table"><thead><tr><th>Booking</th><th>Customer</th><th>Room</th><th>Amount</th><th>Status</th><th>Payment</th></tr></thead><tbody>
        <?php foreach ($bookings as $booking): ?><tr><td>#<?= (int)$booking['id'] ?></td><td><?= htmlspecialchars($booking['full_name']) ?></td><td><?= htmlspecialchars($booking['room_name']) ?></td><td>R <?= number_format((float)$booking['total_amount'],2) ?></td><td><?= htmlspecialchars($booking['status']) ?></td><td><?= htmlspecialchars($booking['payment_status']) ?></td></tr><?php endforeach; ?>
      </tbody></table>
    </div>
  </main>
</div>
</body>
</html>
