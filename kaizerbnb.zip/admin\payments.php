<?php
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = (int)($_POST['booking_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $method = trim($_POST['method'] ?? 'cash');
    $reference = trim($_POST['reference'] ?? '');
    $status = trim($_POST['status'] ?? 'completed');
    $stmt = $conn->prepare('INSERT INTO payments (booking_id, amount, method, reference, status) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('iisss', $booking_id, $amount, $method, $reference, $status);
    $stmt->execute();
    $conn->query("UPDATE bookings SET payment_status='paid' WHERE id=$booking_id");
    header('Location: payments.php');
    exit;
}

$bookings = $conn->query('SELECT id, booking_ref FROM (SELECT id, id AS booking_ref FROM bookings) AS t ORDER BY id DESC')->fetch_all(MYSQLI_ASSOC);
$payments = $conn->query('SELECT p.*, b.id AS booking_id FROM payments p JOIN bookings b ON b.id=p.booking_id ORDER BY p.id DESC')->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <title>Payment Management | Kaizer B&B</title> <link rel="stylesheet" href="../assets/style.css" /> </head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h3>Kaizer B&B</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="rooms.php">Room Management</a>
    <a href="customers.php">Customer Management</a>
    <a href="bookings.php">Bookings</a>
    <a class="active" href="payments.php">Payments</a>
    <a href="reports.php">Reports</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </aside>
  <main class="main-panel">
    <div class="topbar-admin"><div><p class="eyebrow">PAYMENTS</p><h2>Payment Management</h2></div></div>
    <div class="panel" style="margin-bottom:20px;">
      <h3>Record Payment</h3>
      <form method="POST" class="form-grid">
        <div><label>Booking ID</label><input type="number" name="booking_id" required /></div>
        <div><label>Amount</label><input type="number" step="0.01" name="amount" required /></div>
        <div><label>Method</label><select name="method"><option value="cash">Cash</option><option value="card">Card</option><option value="transfer">Transfer</option></select></div>
        <div><label>Reference</label><input name="reference" /></div>
        <div><label>Status</label><select name="status"><option value="completed">Completed</option><option value="pending">Pending</option></select></div>
        <div style="grid-column:1 / -1;"><button class="btn btn-primary" type="submit">Save Payment</button></div>
      </form>
    </div>
    <div class="panel">
      <h3>Payment Records</h3>
      <table class="table"><thead><tr><th>Booking</th><th>Amount</th><th>Method</th><th>Reference</th><th>Status</th></tr></thead><tbody>
        <?php foreach ($payments as $payment): ?><tr><td>#<?= (int)$payment['booking_id'] ?></td><td>R <?= number_format((float)$payment['amount'], 2) ?></td><td><?= htmlspecialchars($payment['method']) ?></td><td><?= htmlspecialchars($payment['reference']) ?></td><td><?= htmlspecialchars($payment['status']) ?></td></tr><?php endforeach; ?>
      </tbody></table>
    </div>
  </main>
</div>
</body>
</html>
