<?php
session_start();
if (empty($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
require '../db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $stmt = $conn->prepare('INSERT INTO customers (full_name, email, phone, address) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('ssss', $full_name, $email, $phone, $address);
    $stmt->execute();
    header('Location: customers.php');
    exit;
}

$result = $conn->query('SELECT * FROM customers ORDER BY id DESC');
$customers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head> <meta charset="UTF-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0" /> <title>Customer Management | Kaizer B&B</title> <link rel="stylesheet" href="../assets/style.css" /> </head>
<body>
<div class="layout">
  <aside class="sidebar">
    <h3>Kaizer B&B</h3>
    <a href="dashboard.php">Dashboard</a>
    <a href="rooms.php">Room Management</a>
    <a class="active" href="customers.php">Customer Management</a>
    <a href="bookings.php">Bookings</a>
    <a href="payments.php">Payments</a>
    <a href="reports.php">Reports</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </aside>
  <main class="main-panel">
    <div class="topbar-admin"><div><p class="eyebrow">CUSTOMERS</p><h2>Customer Management</h2></div></div>
    <div class="panel" style="margin-bottom:20px;">
      <h3>Add Customer</h3>
      <form method="POST" class="form-grid">
        <div><label>Full Name</label><input name="full_name" required /></div>
        <div><label>Email</label><input type="email" name="email" required /></div>
        <div><label>Phone</label><input name="phone" /></div>
        <div style="grid-column:1 / -1;"><label>Address</label><textarea name="address" rows="3"></textarea></div>
        <div style="grid-column:1 / -1;"><button class="btn btn-primary" type="submit">Save Customer</button></div>
      </form>
    </div>
    <div class="panel">
      <h3>Registered Customers</h3>
      <table class="table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Address</th></tr></thead><tbody>
        <?php foreach ($customers as $customer): ?><tr><td><?= htmlspecialchars($customer['full_name']) ?></td><td><?= htmlspecialchars($customer['email']) ?></td><td><?= htmlspecialchars($customer['phone']) ?></td><td><?= htmlspecialchars($customer['address']) ?></td></tr><?php endforeach; ?>
      </tbody></table>
    </div>
  </main>
</div>
</body>
</html>
